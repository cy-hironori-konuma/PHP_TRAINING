<!DOCTYPE HTML>
<html lang="ja-JP">
    <head>
        <meta charset="UTF-8">
        <title>sample</title>
    </head>
    <body>

    <?php
    $string = 'Hello World';
    echo $string;
    ?>

    </body>
</html>